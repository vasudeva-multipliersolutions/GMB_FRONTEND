// DownloadContext.js
import { createContext } from "react";

const DownloadContext = createContext(null);

export default DownloadContext;
