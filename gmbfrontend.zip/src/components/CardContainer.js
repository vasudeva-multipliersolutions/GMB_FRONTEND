import React, { useState, useEffect } from "react";
import SlidePreloader from "../components/SlidePreloader";

export default function CardContainer(props) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const logoMap = {
    "Total Profiles": 'bi-puzzle text-[#8D89BF]',
    "Verified Profiles": 'bi-check2-circle text-green-500',
    "Unverified Profiles": 'bi-slash-circle text-yellow-500',
    "Not Intrested": 'bi-bookmark-dash text-red-500',
    "Out of Organization": 'bi-buildings text-blue-500',
    'Google Search Mobile': 'bi-phone text-[#8D89BF]',
    'Google Search Desktop': 'bi-window-dock text-[#8D89BF]',
    'Google Maps Mobile': 'bi-geo-alt text-[#8D89BF]',
    'Google Maps Desktop': 'bi-pc-display-horizontal text-[#8D89BF]',
    'Calls': 'bi-telephone-inbound text-[#8D89BF]',
    'Directions': 'bi-signpost-split text-[#8D89BF]',
    'Website Clicks': 'bi-sliders text-[#8D89BF]',
    'Searches': 'bi-search text-[#8D89BF]',
    'Department': 'bi-building-fill text-[#8D89BF]',
    'Hospitals': 'bi-radar text-[#8D89BF]',
    'Doctor': 'bi-clipboard-pulse text-[#8D89BF]',
    'Clinic': 'bi-heart-pulse text-[#8D89BF]',
    'MARS': 'bi-pie-chart-fill text-[#8D89BF]',
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-4 border border-[#E5E3FF] hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <div className="flex items-center">
            <i className={`bi ${logoMap[props.head]} text-xl mr-3`}></i>
            <div className="rate-heading">
              <span className="text-sm font-medium text-[#6A6792]">{props.head}</span>
            </div>
          </div>
          
          <div className="mt-2">
            {loading ? (
              <SlidePreloader />
            ) : (
              <div className="text-2xl font-bold text-[#4A476B]">{props.val}</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}